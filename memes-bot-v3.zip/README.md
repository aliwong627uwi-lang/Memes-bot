# MEMES BOT V3

A Solana-only meme coin research and discovery website. It does not connect wallets or execute trades.

## What's included
- Responsive desktop/mobile interface with system, dark and light themes.
- Solana token discovery using public GeckoTerminal new/trending pools and DexScreener latest token profile/boost feeds.
- Token de-duplication, search by token name/symbol/address, sorting and category filters.
- Token detail view with available price, liquidity, volume, market cap/FDV, pool age and external research links.
- Compare up to three loaded tokens.
- Local browser alerts (the page must be open and market refresh must be working).
- Auto refresh with configurable interval.
- Netlify serverless function keeps market aggregation behind a same-origin endpoint.

## Deploy to Netlify
This project uses a Netlify Function. Do **not** deploy only the static folder through a method that omits functions.

1. Create a GitHub repository and upload the complete contents of this folder, preserving `netlify.toml` and `netlify/functions/market.js`.
2. In Netlify choose **Add new site → Import an existing project**, connect the repository.
3. Build command: `npm run build`; publish directory: `.`.
4. Deploy. Netlify should detect the function automatically.
5. Open the deployed site and check `/api/market` (it should return JSON containing `tokens`, `sources`, and `count`).

For local development:
- Install Node.js.
- Run `npm install`.
- Run `npm run dev`.

## Important market-data limitations
- The number of unique tokens is determined by public upstream feeds and their rate limits. This code queries up to ten GeckoTerminal new-pool pages plus trending pools, and DexScreener latest profiles/boosts. It does **not** promise 200–500 tokens on every refresh. Do not pad the list with invented tokens.
- A token can have missing price, market cap, liquidity, volume, image or pool creation time. The UI shows `N/A` where the source does not provide a field.
- Pool age is the age of the indexed pool, not necessarily the original token mint age.
- Holder count, accurate buy/sell ratio, OHLCV chart history and verified launch/mint metadata need a dedicated provider or additional indexer integration. They are not fabricated in this build.
- Social Radar is intentionally marked as not connected. Real posts, celebrity mentions, author identities, timestamps and links require an approved social-data provider/API and credentials.
- AI research chat requires an AI provider and server-side secret key. No fake AI responses are shown.
- Local alerts are browser/device-local and only check while the website is open and refreshing. They are not push alerts from a background server.
- Public API availability, rate limits and response schemas can change.

## Recommended next integrations
1. Add a paid Solana data provider (e.g. Helius, Birdeye or another provider) for reliable token metadata, holders, transactions, OHLCV and broader discovery.
2. Add an approved social listening provider for X/public social data.
3. Add an AI API key as a Netlify environment variable and implement the private coin-research endpoint.
4. Add server-side scheduled monitoring and push/email delivery if persistent alerts are required.

## Security
Never put API secrets in `app.js`, HTML or other browser-delivered files. Store them in Netlify environment variables and access them only from Netlify Functions.
