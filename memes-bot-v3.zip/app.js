const $ = s => document.querySelector(s);
const state = {tokens:[], filtered:[], visible:50, category:"all", currentView:"discover", compare:[], alerts:JSON.parse(localStorage.getItem("mb-alerts")||"[]"), refreshTimer:null, interval:Number(localStorage.getItem("mb-interval")||60)};
const fmt = (n, digits=2) => { if(n===null||n===undefined||!Number.isFinite(Number(n))) return "N/A"; n=Number(n); if(Math.abs(n)>=1e9)return "$"+(n/1e9).toFixed(2)+"B";if(Math.abs(n)>=1e6)return "$"+(n/1e6).toFixed(2)+"M";if(Math.abs(n)>=1e3)return "$"+(n/1e3).toFixed(2)+"K";if(Math.abs(n)<.0001&&n!==0)return "$"+n.toExponential(2);return "$"+n.toLocaleString("en-US",{maximumFractionDigits:digits}); };
const compact = n => {if(!Number.isFinite(Number(n)))return "N/A";n=Number(n);return n>=1e9?(n/1e9).toFixed(2)+"B":n>=1e6?(n/1e6).toFixed(2)+"M":n>=1e3?(n/1e3).toFixed(1)+"K":n.toFixed(0)};
const pct = n => Number.isFinite(Number(n)) ? (Number(n)>0?"+":"")+Number(n).toFixed(2)+"%" : "N/A";
const ageText = date => {if(!date)return "N/A";const ms=Date.now()-new Date(date).getTime();if(!Number.isFinite(ms)||ms<0)return "N/A";const m=Math.floor(ms/60000);if(m<60)return m+"m";const h=Math.floor(m/60);if(h<24)return h+"h";return Math.floor(h/24)+"d"};
function toast(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2400)}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function icon(token){return token.image?`<img src="${esc(token.image)}" onerror="this.style.display='none'">`:(esc((token.symbol||token.name||"?").slice(0,2).toUpperCase()))}
function mapToken(t){return {address:t.address||t.mint||"",name:t.name||"Unknown token",symbol:t.symbol||"—",image:t.image||t.icon||"",price:Number(t.priceUsd)||null,change1h:Number(t.change1h),change24h:Number(t.change24h),liquidity:Number(t.liquidity)||null,volume24h:Number(t.volume24h)||null,marketcap:Number(t.marketcap)||null,fdv:Number(t.fdv)||null,pairCreatedAt:t.pairCreatedAt||null,dex:t.dex||"Unknown",url:t.url||"",chain:"solana",source:t.source||""}}
async function api(path){const r=await fetch(path,{headers:{"Accept":"application/json"}});if(!r.ok)throw new Error("API "+r.status);return r.json()}
async function loadMarket(silent=false){
 if(!silent) $("#token-table").innerHTML='<tr><td colspan="9" class="loading-cell"><span class="spinner"></span> Loading live Solana market data…</td></tr>';
 try{
  const data=await api("/api/market");
  state.tokens=(data.tokens||[]).map(mapToken).filter(t=>t.address);
  state.tokens.sort((a,b)=>(b.volume24h||0)-(a.volume24h||0));
  $("#connection-label").textContent="Market feeds connected";
  $("#connection-label").style.color="var(--green)";
  $("#token-count").textContent=state.tokens.length.toLocaleString();
  $("#token-count-note").textContent=(data.sources||[]).join(" + ")||"Public market feeds";
  $("#total-volume").textContent=fmt(state.tokens.reduce((s,t)=>s+(t.volume24h||0),0),0);
  $("#last-updated").textContent=new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"});
  $("#sol-price").textContent=data.solPrice?fmt(data.solPrice):"N/A";
  render();
  renderSpecialViews();
  checkAlerts();
 }catch(e){
  $("#connection-label").textContent="Market feed unavailable";
  $("#connection-label").style.color="var(--red)";
  if(!state.tokens.length)$("#token-table").innerHTML=`<tr><td colspan="9" class="loading-cell">Could not load market data. ${esc(e.message)}. Try Refresh in a moment.</td></tr>`;
  toast("Market data could not be refreshed");
 }
}
function filterTokens(){
 const q=$("#search-input").value.trim().toLowerCase();let arr=[...state.tokens];
 if(q)arr=arr.filter(t=>[t.name,t.symbol,t.address].some(v=>String(v||"").toLowerCase().includes(q)));
 switch(state.category){
  case "new":arr=arr.filter(t=>Date.now()-new Date(t.pairCreatedAt||0).getTime()<86400000).sort((a,b)=>(new Date(b.pairCreatedAt||0))-(new Date(a.pairCreatedAt||0)));break;
  case "trending":arr.sort((a,b)=>(b.volume24h||0)-(a.volume24h||0));break;
  case "gainers":arr.sort((a,b)=>(b.change24h||-Infinity)-(a.change24h||-Infinity));break;
  case "losers":arr.sort((a,b)=>(a.change24h||Infinity)-(b.change24h||Infinity));break;
  case "liquidity":arr.sort((a,b)=>(b.liquidity||0)-(a.liquidity||0));break;
  case "marketcap":arr.sort((a,b)=>(b.marketcap||b.fdv||0)-(a.marketcap||a.fdv||0));break;
 }
 const sort=$("#sort-select").value;
 if(sort==="volume")arr.sort((a,b)=>(b.volume24h||0)-(a.volume24h||0));
 if(sort==="liquidity")arr.sort((a,b)=>(b.liquidity||0)-(a.liquidity||0));
 if(sort==="marketcap")arr.sort((a,b)=>(b.marketcap||b.fdv||0)-(a.marketcap||a.fdv||0));
 if(sort==="change")arr.sort((a,b)=>(b.change24h||-Infinity)-(a.change24h||-Infinity));
 if(sort==="age")arr.sort((a,b)=>new Date(b.pairCreatedAt||0)-new Date(a.pairCreatedAt||0));
 return arr;
}
function render(){
 state.filtered=filterTokens();const shown=state.filtered.slice(0,state.visible);
 $("#token-table").innerHTML=shown.length?shown.map((t,i)=>`<tr>
 <td><div class="token-cell"><div class="token-icon">${icon(t)}</div><div><div class="token-name">${esc(t.name)}</div><div class="token-symbol">${esc(t.symbol)} · ${esc(t.address.slice(0,4))}…${esc(t.address.slice(-4))}</div></div></div></td>
 <td>${fmt(t.price,8)}</td><td class="${t.change1h>=0?"positive":"negative"}">${pct(t.change1h)}</td><td class="${t.change24h>=0?"positive":"negative"}">${pct(t.change24h)}</td>
 <td>${fmt(t.liquidity,0)}</td><td>${fmt(t.volume24h,0)}</td><td>${fmt(t.marketcap||t.fdv,0)}</td><td>${ageText(t.pairCreatedAt)}</td><td><button class="token-open" data-address="${esc(t.address)}">View ↗</button></td></tr>`).join(""):`<tr><td colspan="9" class="loading-cell">No matching tokens found in the currently indexed market feeds.</td></tr>`;
 $("#result-count").textContent=`Showing ${shown.length} of ${state.filtered.length} matching tokens · ${state.tokens.length} unique tokens loaded`;
 $("#load-more").hidden=shown.length>=state.filtered.length;
 $("#load-more").textContent="Load more ↓";
}
function renderSpecialViews(){
 const trending=[...state.tokens].sort((a,b)=>(b.volume24h||0)-(a.volume24h||0)).slice(0,12);
 const fresh=[...state.tokens].filter(t=>t.pairCreatedAt).sort((a,b)=>new Date(b.pairCreatedAt)-new Date(a.pairCreatedAt)).slice(0,12);
 const card=t=>`<article class="panel-card" data-address="${esc(t.address)}"><h3>${esc(t.name)} <span class="muted">(${esc(t.symbol)})</span></h3><p>${esc(t.address.slice(0,8))}…${esc(t.address.slice(-7))}</p><div class="panel-metrics"><div>PRICE<b>${fmt(t.price,7)}</b></div><div>24H CHANGE<b class="${t.change24h>=0?"positive":"negative"}">${pct(t.change24h)}</b></div><div>VOLUME<b>${fmt(t.volume24h,0)}</b></div></div></article>`;
 $("#trending-content").innerHTML=trending.map(card).join("")||'<div class="empty-state">No trending data available.</div>';
 $("#new-content").innerHTML=fresh.map(card).join("")||'<div class="empty-state">No new-pool data available.</div>';
}
function showCoin(address){
 const t=state.tokens.find(x=>x.address===address);if(!t)return;
 const links=[["DexScreener",`https://dexscreener.com/solana/${encodeURIComponent(address)}`],["Birdeye",`https://birdeye.so/token/${encodeURIComponent(address)}?chain=solana`],["Solscan",`https://solscan.io/token/${encodeURIComponent(address)}`]];
 $("#coin-detail").innerHTML=`<div class="detail-head"><div class="token-icon">${icon(t)}</div><div><h2>${esc(t.name)} <span class="muted">(${esc(t.symbol)})</span></h2><p>${esc(address)}</p></div></div><div class="detail-price">${fmt(t.price,9)} <span class="${t.change24h>=0?"positive":"negative"}" style="font-size:13px">${pct(t.change24h)} 24H</span></div><div class="detail-grid">${[["LIQUIDITY",fmt(t.liquidity,0)],["24H VOLUME",fmt(t.volume24h,0)],["MARKET CAP",fmt(t.marketcap,0)],["FDV",fmt(t.fdv,0)],["1H CHANGE",pct(t.change1h)],["POOL AGE",ageText(t.pairCreatedAt)]].map(([a,b])=>`<div class="detail-metric"><small>${a}</small><b>${b}</b></div>`).join("")}</div><div class="sentiment">Market mood: ${t.change24h>3?"🟢 Positive price movement":t.change24h< -3?"🔴 Negative price movement":"⚪ Mixed / neutral movement"}. This is a simple price-change indicator, not an AI prediction. Holder count and buy/sell ratio are not supplied by this feed.</div><div class="detail-links">${links.map(([n,u])=>`<a href="${u}" target="_blank" rel="noopener noreferrer">${n} ↗</a>`).join("")}</div>`;
 $("#coin-modal").hidden=false;
}
function setView(name){
 state.currentView=name;document.querySelectorAll(".view").forEach(v=>v.classList.remove("active"));$("#view-"+name).classList.add("active");
 document.querySelectorAll(".nav-item[data-view]").forEach(b=>b.classList.toggle("active",b.dataset.view===name));
 $("#page-title").textContent=name.toUpperCase().replace("-"," ");
 $("#sidebar").classList.remove("open");
}
function addCompare(){
 const q=$("#compare-search").value.trim().toLowerCase();if(!q)return;
 const t=state.tokens.find(t=>t.address.toLowerCase()===q||t.symbol.toLowerCase()===q||t.name.toLowerCase()===q||t.address.toLowerCase().includes(q));
 if(!t){toast("Token not found in loaded market data");return}
 if(state.compare.some(x=>x.address===t.address)){toast("Token already added");return}
 if(state.compare.length>=3){toast("Compare up to three tokens");return}
 state.compare.push(t);$("#compare-search").value="";renderCompare();
}
function renderCompare(){
 if(!state.compare.length){$("#compare-results").innerHTML='<div class="empty-state">Add up to three tokens to compare their market metrics.</div>';return}
 const metrics=[["Price",t=>fmt(t.price,8)],["24h change",t=>pct(t.change24h)],["Liquidity",t=>fmt(t.liquidity,0)],["24h volume",t=>fmt(t.volume24h,0)],["Market cap",t=>fmt(t.marketcap||t.fdv,0)],["Pool age",t=>ageText(t.pairCreatedAt)]];
 $("#compare-results").innerHTML=`<div style="overflow:auto"><table class="compare-table"><thead><tr><th>METRIC</th>${state.compare.map(t=>`<th>${esc(t.symbol)} <button data-remove="${esc(t.address)}" class="token-open">×</button></th>`).join("")}</tr></thead><tbody>${metrics.map(([label,fn])=>`<tr><td>${label}</td>${state.compare.map(t=>`<td>${fn(t)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
}
function renderAlerts(){
 $("#alert-count").textContent=state.alerts.filter(a=>!a.triggered).length;
 $("#alerts-list").innerHTML=state.alerts.length?state.alerts.map((a,i)=>`<div class="alert-item"><div><b>${esc(a.symbol||a.address.slice(0,8)+"…")}</b><small>${a.condition==="above"?"Above":"Below"} ${fmt(a.target,8)} · ${a.triggered?"Triggered":"Watching"}</small></div><button class="token-open" data-delete-alert="${i}">Remove</button></div>`).join(""):'<div class="empty-state">No alerts yet. Create one above to watch a token price.</div>';
}
async function createAlert(){
 const address=$("#alert-address").value.trim(),target=Number($("#alert-target").value),condition=$("#alert-condition").value;
 if(!address||!Number.isFinite(target)||target<=0){toast("Enter a token address and valid target price");return}
 const t=state.tokens.find(x=>x.address===address);
 state.alerts.push({address,target,condition,symbol:t?.symbol||"",triggered:false,created:Date.now()});
 localStorage.setItem("mb-alerts",JSON.stringify(state.alerts));$("#alert-address").value="";$("#alert-target").value="";renderAlerts();toast("Alert saved on this device");
}
function checkAlerts(){
 let changed=false;
 state.alerts.forEach(a=>{if(a.triggered)return;const t=state.tokens.find(x=>x.address===a.address);if(t&&t.price!==null&&((a.condition==="above"&&t.price>=a.target)||(a.condition==="below"&&t.price<=a.target))){a.triggered=true;changed=true;toast(`${a.symbol||"Token"} research alert triggered`);if("Notification"in window&&Notification.permission==="granted")new Notification("MEMES BOT alert",{body:`${a.symbol||"Token"} reached ${fmt(t.price,8)}`})}});
 if(changed)localStorage.setItem("mb-alerts",JSON.stringify(state.alerts));renderAlerts();
}
function setTheme(mode){localStorage.setItem("mb-theme",mode);const dark=mode==="dark"||(mode==="system"&&matchMedia("(prefers-color-scheme: dark)").matches);document.body.classList.toggle("light",!dark);$("#appearance-select").value=mode}
function setup(){
 const savedTheme=localStorage.getItem("mb-theme")||"system";setTheme(savedTheme);$("#appearance-select").value=savedTheme;$("#interval-select").value=String(state.interval);
 $("#search-input").addEventListener("input",()=>{state.visible=50;render()});
 $("#sort-select").addEventListener("change",render);
 $("#refresh-btn").addEventListener("click",()=>loadMarket());
 $("#load-more").addEventListener("click",()=>{state.visible+=50;render()});
 $("#category-tabs").addEventListener("click",e=>{const b=e.target.closest("[data-category]");if(!b)return;state.category=b.dataset.category;state.visible=50;document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===b));$("#list-heading").textContent=b.textContent;render()});
 $("#token-table").addEventListener("click",e=>{const b=e.target.closest("[data-address]");if(b)showCoin(b.dataset.address)});
 ["trending-content","new-content"].forEach(id=>$("#"+id).addEventListener("click",e=>{const b=e.target.closest("[data-address]");if(b)showCoin(b.dataset.address)}));
 document.querySelectorAll(".nav-item[data-view]").forEach(b=>b.addEventListener("click",()=>setView(b.dataset.view)));
 $("#theme-toggle").addEventListener("click",()=>setTheme(document.body.classList.contains("light")?"dark":"light"));
 $("#appearance-select").addEventListener("change",e=>setTheme(e.target.value));
 $("#interval-select").addEventListener("change",e=>{state.interval=Number(e.target.value);localStorage.setItem("mb-interval",state.interval);startTimer();toast("Refresh interval updated")});
 $("#menu-toggle").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));
 $("#modal-close").addEventListener("click",()=>$("#coin-modal").hidden=true);
 $("#coin-modal").addEventListener("click",e=>{if(e.target.id==="coin-modal")$("#coin-modal").hidden=true});
 $("#compare-add").addEventListener("click",addCompare);$("#compare-search").addEventListener("keydown",e=>{if(e.key==="Enter")addCompare()});
 $("#compare-results").addEventListener("click",e=>{const b=e.target.closest("[data-remove]");if(b){state.compare=state.compare.filter(t=>t.address!==b.dataset.remove);renderCompare()}});
 $("#create-alert").addEventListener("click",createAlert);
 $("#alerts-list").addEventListener("click",e=>{const b=e.target.closest("[data-delete-alert]");if(b){state.alerts.splice(Number(b.dataset.deleteAlert),1);localStorage.setItem("mb-alerts",JSON.stringify(state.alerts));renderAlerts()}});
 renderAlerts();
 if("Notification"in window&&Notification.permission==="default")Notification.requestPermission().catch(()=>{});
 matchMedia("(prefers-color-scheme: dark)").addEventListener?.("change",()=>{if((localStorage.getItem("mb-theme")||"system")==="system")setTheme("system")});
}
function startTimer(){if(state.refreshTimer)clearInterval(state.refreshTimer);state.refreshTimer=setInterval(()=>loadMarket(true),state.interval*1000)}
setup();loadMarket();startTimer();
