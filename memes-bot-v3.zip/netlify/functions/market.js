const headers = {"content-type":"application/json; charset=utf-8","cache-control":"public, max-age=20"};

async function getJson(url) {
  const res = await fetch(url, {headers: {"accept":"application/json","user-agent":"MemesBot/3.0"}});
  if (!res.ok) throw new Error(`Upstream ${res.status}`);
  return res.json();
}
const num = v => { const n=Number(v); return Number.isFinite(n)?n:null; };
function normalizeDex(pair, source) {
  const base=pair.baseToken||{};
  const liq=num(pair.liquidity?.usd),vol=num(pair.volume?.h24);
  return {
    address:base.address,name:base.name,symbol:base.symbol,image:pair.info?.imageUrl||"",
    priceUsd:num(pair.priceUsd),change1h:num(pair.priceChange?.h1),change24h:num(pair.priceChange?.h24),
    liquidity:liq,volume24h:vol,marketcap:num(pair.marketCap),fdv:num(pair.fdv),
    pairCreatedAt:pair.pairCreatedAt?new Date(pair.pairCreatedAt).toISOString():null,
    dex:pair.dexId||"dexscreener",url:pair.url||"",source
  };
}
function normalizeGecko(pool) {
  const a=pool.attributes||{}, rel=pool.relationships||{};
  const baseId=rel.base_token?.data?.id||"";
  const parts=baseId.split("_");
  const address=parts.length>1?parts.slice(1).join("_"):baseId;
  return {
    address,name:a.name?.split(" / ")[0]||"Unknown token",symbol:a.name?.split(" / ")[0]?.split(" ")[0]||"—",
    image:a.image_url||"",priceUsd:num(a.base_token_price_usd),change1h:num(a.price_change_percentage?.h1),
    change24h:num(a.price_change_percentage?.h24),liquidity:num(a.reserve_in_usd),
    volume24h:num(a.volume_usd?.h24),marketcap:num(a.market_cap_usd),fdv:num(a.fdv_usd),
    pairCreatedAt:a.pool_created_at||null,dex:a.dex_id||"geckoterminal",url:`https://www.geckoterminal.com/solana/pools/${a.address||""}`,source:"GeckoTerminal"
  };
}
exports.handler = async () => {
  const sources=[], all=[];
  const jobs=[];
  // GeckoTerminal exposes paginated new pools and a trending pool feed.
  jobs.push((async()=>{
    const urls=[];
    for(let p=1;p<=10;p++) urls.push(`https://api.geckoterminal.com/api/v2/networks/solana/new_pools?page=${p}`);
    urls.push("https://api.geckoterminal.com/api/v2/networks/solana/trending_pools");
    const results=await Promise.allSettled(urls.map(getJson));
    for(const r of results) if(r.status==="fulfilled"){
      for(const pool of r.value.data||[]) {const t=normalizeGecko(pool);if(t.address)all.push(t)}
    }
    if(results.some(r=>r.status==="fulfilled"))sources.push("GeckoTerminal");
  })());
  jobs.push((async()=>{
    const urls=[
      "https://api.dexscreener.com/token-profiles/latest/v1",
      "https://api.dexscreener.com/token-boosts/latest/v1",
      "https://api.dexscreener.com/token-boosts/top/v1"
    ];
    const results=await Promise.allSettled(urls.map(getJson));
    const addresses=new Set();
    for(const r of results) if(r.status==="fulfilled") for(const x of r.value||[]) if(x.chainId==="solana"&&x.tokenAddress)addresses.add(x.tokenAddress);
    const list=[...addresses];
    for(let i=0;i<list.length;i+=30){
      try{
        const data=await getJson(`https://api.dexscreener.com/tokens/v1/solana/${list.slice(i,i+30).join(",")}`);
        for(const pair of data||[]) {const t=normalizeDex(pair,"DexScreener");if(t.address)all.push(t)}
      }catch(e){}
    }
    if(results.some(r=>r.status==="fulfilled"))sources.push("DexScreener");
  })());
  await Promise.allSettled(jobs);
  // SOL/USD reference price from CoinGecko public simple-price endpoint.
  let solPrice=null;
  try{const s=await getJson("https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd");solPrice=num(s.solana?.usd)}catch(e){}
  // Prefer DexScreener pair-level metrics, then GeckoTerminal; dedupe by mint address.
  const map=new Map();
  for(const t of all){
    const key=t.address;if(!key)continue;
    const old=map.get(key);
    const score=x=>(x.priceUsd?4:0)+(x.volume24h?2:0)+(x.liquidity?2:0)+(x.marketcap||x.fdv?1:0)+(x.image?1:0);
    if(!old||score(t)>score(old))map.set(key,t);
    else if(old&&(!old.image&&t.image))old.image=t.image;
  }
  const tokens=[...map.values()].sort((a,b)=>(b.volume24h||0)-(a.volume24h||0));
  return {statusCode:200,headers,body:JSON.stringify({tokens,solPrice,sources,updatedAt:new Date().toISOString(),count:tokens.length,notice:"Coverage depends on upstream public API availability and rate limits. The API does not guarantee a fixed token count."})};
};
